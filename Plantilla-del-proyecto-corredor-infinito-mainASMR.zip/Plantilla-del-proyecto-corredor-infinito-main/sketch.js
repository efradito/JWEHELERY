let fondo, fondoimg, nave, naveimg, asteroide, asteroideimg, asteroidegroup, alien, alienimg, aliengroup, cosaderepuesto, cosaderepuestoimg, cosaderepuestogroup;
let gameState = "play";
let score = 0;

function preload(){
  fondoimg = loadImage("fondo.png");
  asteroideimg = loadImage("asteroide.png");
  alienimg = loadImage("alien.png");
  naveimg = loadImage("nave espacial.png");
}

function setup() {
  createCanvas(windowWidth, windowHeight);

  // bullet = createSprite() proximamente.loop();
  fondo=createSprite(width/2,200);
  fondo.addImage(fondoimg);
  fondo.velocityY = 2;

  asteroidegroup = new Group();
  aliengroup = new Group();
  cosaderepuestogroup = new Group();


  nave = createSprite(windowWidth/2,  windowHeight/2);
  nave.scale = 0.3;
  nave.addImage("nave", naveimg);
}

function draw() {
    background(255);
    
    if(fondo.y > 400){
         fondo.y = 300
       } 
     
     if (gameState === "play") {
        score = score + 1
       if(keyDown("left_arrow")){
        nave.x = nave.x - 3;
       }
       if(keyDown("right_arrow")){
     
         nave.x = nave.x + 3;         
       }
       text("tu puntuacion: "+score,230, 200);

       
         spawn();
   
     
   
      /*  if(cosaderepuesto.isTouching(nave)){
         nave.velocityY = 0;
       }*/
       if(cosaderepuestogroup.isTouching(nave) || nave.y > 600){
         nave.destroy();
         gameState = "end";
       }
       
       
     
     
   }
     if (gameState === "end"){
       stroke("yellow");
       fill("yellow");
       textSize(200);
       text("Fin del juego", 230,250);
       textSize(40);
       text("tu puntuacion: "+score,230, 400);
       if (keyDown("space")){
           gameState = "play"
       }
     }
   }
   
   function spawn()
    {
    
     if (frameCount % 240 === 0) {
        var randomx = Math.round(random(50,windowWidth));
       var alien = createSprite(randomx, -50);
       var asteroide = createSprite(randomx,-50);
       var cosaderepuesto = createSprite(randomx,15, 20, 20);
       cosaderepuesto.width = asteroide.width;
       cosaderepuesto.height = 2;
       
       
       alien.addImage(alienimg);
       asteroide.addImage(alienimg);
       
       alien.velocityY = 3;
       asteroide.velocityY = 3;
       cosaderepuesto.velocityY = 3;
   
       

        
   nave.depth = alien.depth;
       nave.depth +=1;
       

    alien.lifetime = 800;
       asteroide.lifetime = 800;
       cosaderepuesto.lifetime = 800;
       

        aliengroup.add(alien);
       cosaderepuesto.debug = true;
       asteroidegroup.add(asteroide);
       cosaderepuestogroup.add(cosaderepuesto);
     }
     drawSprites();
}